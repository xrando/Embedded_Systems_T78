#ifndef WIFI_H
#define WIFI_H

// WIFI Credentials - take care if pushing to github!
extern char WIFI_SSID[] = "TimoGS21";
extern char WIFI_PASSWORD[] = "eueo9438";

void wifi_init();